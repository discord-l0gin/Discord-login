require('dotenv').config();
const express = require('express');
const session = require('express-session');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3000;

const {
  DISCORD_CLIENT_ID,
  DISCORD_CLIENT_SECRET,
  DISCORD_REDIRECT_URI,
  SESSION_SECRET,
  ADMIN_PASSWORD
} = process.env;

// سجل بسيط في الذاكرة لآخر الحسابات اللي سجلت دخول (اسم المستخدم بس - من غير أي باسورد)
// لو السيرفر اتعمله ريستارت، السجل بيتصفر
const loginLog = [];

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: SESSION_SECRET || 'change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 } // يوم واحد
}));

// الصفحة الرئيسية
app.get('/', (req, res) => {
  if (req.session.user) {
    return res.redirect('/dashboard');
  }
  res.sendFile(__dirname + '/public/login.html');
});

// يبدأ تسجيل الدخول: يوجه المستخدم لصفحة ديسكورد
app.get('/login', (req, res) => {
  const params = new URLSearchParams({
    client_id: DISCORD_CLIENT_ID,
    redirect_uri: DISCORD_REDIRECT_URI,
    response_type: 'code',
    scope: 'identify email'
  });
  res.redirect(`https://discord.com/api/oauth2/authorize?${params.toString()}`);
});

// ديسكورد بيرجع هنا بعد الموافقة
app.get('/callback', async (req, res) => {
  const code = req.query.code;
  if (!code) return res.redirect('/?error=no_code');

  try {
    // بادل الـ code بتوكن
    const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: DISCORD_REDIRECT_URI
      })
    });
    const tokenData = await tokenRes.json();

    if (!tokenData.access_token) {
      console.error('Token exchange failed:', tokenData);
      return res.redirect('/?error=token_failed');
    }

    // هات بيانات المستخدم
    const userRes = await fetch('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    const user = await userRes.json();

    req.session.user = {
      id: user.id,
      username: user.username,
      avatar: user.avatar,
      global_name: user.global_name
    };

    // سجل عملية الدخول (اسم المستخدم ووقت الدخول بس)
    loginLog.unshift({
      username: user.username,
      global_name: user.global_name,
      id: user.id,
      time: new Date().toISOString()
    });
    if (loginLog.length > 200) loginLog.length = 200; // حد أقصى عشان الذاكرة

    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    res.redirect('/?error=server_error');
  }
});

// صفحة بعد تسجيل الدخول
app.get('/dashboard', (req, res) => {
  if (!req.session.user) return res.redirect('/');
  res.sendFile(__dirname + '/public/dashboard.html');
});

// بيانات المستخدم الحالي (يستخدمها dashboard.html)
app.get('/api/me', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'not logged in' });
  res.json(req.session.user);
});

// تسجيل خروج
app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// ====== لوحة الأدمن: قائمة بأسماء اللي سجلوا دخول (من غير باسوردات) ======

// صفحة إدخال باسورد الأدمن
app.get('/admin', (req, res) => {
  if (req.session.isAdmin) return res.redirect('/admin/panel');
  res.send(`
    <!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>دخول الأدمن</title>
    <style>
      body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
        font-family:'Segoe UI',Tahoma,sans-serif;
        background:radial-gradient(circle at 20% 20%,#2b3fd6 0%,transparent 50%),
                   radial-gradient(circle at 80% 80%,#1a1a6b 0%,transparent 50%),
                   linear-gradient(135deg,#0f1033 0%,#141852 40%,#1b2a7a 100%);}
      .card{width:min(320px,90vw);padding:32px;background:rgba(255,255,255,0.08);
        border:1px solid rgba(255,255,255,0.25);border-radius:16px;
        backdrop-filter:blur(20px);text-align:center;color:#fff}
      input{width:100%;padding:12px;margin:16px 0;border-radius:10px;border:none;
        background:rgba(255,255,255,0.1);color:#fff;font-size:16px;box-sizing:border-box;text-align:center}
      button{width:100%;padding:12px;border:none;border-radius:10px;background:#5865F2;
        color:#fff;font-size:16px;cursor:pointer}
      .err{color:#ff8a8a;font-size:13px;margin-top:10px}
    </style></head><body>
      <form class="card" method="POST" action="/admin/login">
        <h2>دخول الأدمن</h2>
        <input type="password" name="password" placeholder="الباسورد" autofocus required>
        <button type="submit">دخول</button>
        ${req.query.error ? '<div class="err">باسورد غلط</div>' : ''}
      </form>
    </body></html>
  `);
});

app.post('/admin/login', (req, res) => {
  if (req.body.password && req.body.password === (ADMIN_PASSWORD || '')) {
    req.session.isAdmin = true;
    return res.redirect('/admin/panel');
  }
  res.redirect('/admin?error=1');
});

// لوحة الأدمن نفسها
app.get('/admin/panel', (req, res) => {
  if (!req.session.isAdmin) return res.redirect('/admin');

  const rows = loginLog.map(entry => `
    <tr>
      <td>${entry.global_name || entry.username}</td>
      <td>@${entry.username}</td>
      <td>${new Date(entry.time).toLocaleString('ar-EG')}</td>
    </tr>
  `).join('');

  res.send(`
    <!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>قائمة الدخول</title>
    <style>
      body{margin:0;min-height:100vh;font-family:'Segoe UI',Tahoma,sans-serif;
        background:radial-gradient(circle at 20% 20%,#2b3fd6 0%,transparent 50%),
                   radial-gradient(circle at 80% 80%,#1a1a6b 0%,transparent 50%),
                   linear-gradient(135deg,#0f1033 0%,#141852 40%,#1b2a7a 100%);
        color:#fff;padding:20px}
      .wrap{max-width:600px;margin:0 auto;background:rgba(255,255,255,0.08);
        border:1px solid rgba(255,255,255,0.25);border-radius:16px;padding:24px;
        backdrop-filter:blur(20px)}
      h2{margin-top:0}
      table{width:100%;border-collapse:collapse;font-size:14px}
      th,td{padding:10px;text-align:right;border-bottom:1px solid rgba(255,255,255,0.15)}
      th{color:rgba(255,255,255,0.6);font-weight:600}
      .empty{color:rgba(255,255,255,0.5);text-align:center;padding:30px 0}
      a{color:rgba(255,255,255,0.6);font-size:13px}
    </style></head><body>
      <div class="wrap">
        <h2>الحسابات اللي سجلت دخول عن طريق Discord</h2>
        ${loginLog.length ? `<table><thead><tr><th>الاسم</th><th>اليوزر</th><th>الوقت</th></tr></thead><tbody>${rows}</tbody></table>`
                          : '<div class="empty">محدش سجل دخول لسه</div>'}
        <br><a href="/admin/logout">خروج من لوحة الأدمن</a>
      </div>
    </body></html>
  `);
});

app.get('/admin/logout', (req, res) => {
  req.session.isAdmin = false;
  res.redirect('/admin');
});

app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
