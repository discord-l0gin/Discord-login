# نظام تسجيل دخول بـ Discord OAuth

## الخطوات محلياً (لو هتجرب على جهاز فيه Node.js)
1. `npm install`
2. انسخ `.env.example` إلى `.env` واملى القيم (الـ Client Secret من Discord Developer Portal)
3. `npm start`
4. افتح http://localhost:3000

## الرفع على Render (استضافة مجانية)
1. اعمل حساب على GitHub وارفع الملفات دي في repository جديد
2. اعمل حساب على https://render.com وسجل دخول بـ GitHub
3. New -> Web Service -> اختار الـ repo
4. Build Command: `npm install`
5. Start Command: `npm start`
6. في Environment Variables ضيف:
   - DISCORD_CLIENT_ID
   - DISCORD_CLIENT_SECRET
   - DISCORD_REDIRECT_URI (هيبقى https://اسم-الموقع.onrender.com/callback)
   - SESSION_SECRET
7. في Discord Developer Portal -> OAuth2 -> Redirects: ضيف نفس الـ Redirect URI
